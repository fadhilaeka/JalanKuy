<?php
// Include koneksi ke database
include('koneksi.php');

// Get the booking ID to be deleted
$id = isset($_GET['id']) ? $_GET['id'] : 0;

// Delete the booking record
if ($id > 0) {
    $deleteQuery = "DELETE FROM tb_booking WHERE id = $id";
    $result = mysqli_query($conn, $deleteQuery);

    if ($result) {
        echo "Pesanan berhasil dibatalkan.";
    } else {
        echo "Gagal membatalkan pesanan.";
    }
}

// Close database connection
mysqli_close($conn);

// Redirect back to cek-pesanan.php
header("Location: cek-pesanan.php");
exit();
?>
