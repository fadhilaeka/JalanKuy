<?php
include('koneksi.php');
require_once("dompdf/autoload.inc.php");

use Dompdf\Dompdf;

$dompdf = new Dompdf();
$query = mysqli_query($conn, "SELECT * FROM tb_categories");
$html = '<center><h3>Data Schedule</h3></center><hr/><br>';
$html .= '<table border="1" width="100%">
            <tr>
                <th>No</th>
                <th>Transportatioon</th>
                <th>Kelas</th>
                <th>Fasilitas</th>
                <th>Harga</th>
            </tr>';
$no = 1;
while ($categories = mysqli_fetch_array($query)) {
    $html .= "<tr>
                <td>" . $no . "</td>
                <td>" . $categories['transportation'] . "</td>
                <td>" . $categories['kelas'] . "</td>
                <td>" . $categories['fasilitas'] . "</td>
                <td>" . $categories['harga'] . "</td>
            </tr>";
    $no++;
}
$html .= "</table>";
$dompdf->loadHtml($html);
// Setting ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'potrait');
// Rendering dari HTML Ke PDF
$dompdf->render();
// Melakukan output file Pdf
$dompdf->stream('laporan-categories.pdf');
?>