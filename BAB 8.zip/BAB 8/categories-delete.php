<?php
// Include database connection
include('koneksi.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete query
    $deleteQuery = "DELETE FROM tb_categories WHERE id = '$id'";

    if (mysqli_query($conn, $deleteQuery)) {
        echo json_encode(['success' => true]);
        header('Location: categories.php');
    } else {
        echo json_encode(['success' => false, 'error' => mysqli_error($conn)]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'ID not provided']);
}

mysqli_close($conn);
?>