<?php
// Include koneksi ke database
include('koneksi.php');

// Query untuk mendapatkan semua pilihan transportasi yang unik
$transportationQuery = "SELECT DISTINCT transportation FROM tb_categories";
$transportationResult = mysqli_query($conn, $transportationQuery);

// Ambil data filter dari dropdown (jika ada)
$filterTransportation = isset($_GET['transportation']) ? $_GET['transportation'] : '';

// Query untuk menampilkan data dengan filter
$query = "SELECT * FROM tb_categories WHERE 1=1";
if (!empty($filterTransportation)) {
    $query .= " AND transportation = '$filterTransportation'";
}
$result = mysqli_query($conn, $query);

// Jika query gagal
if (!$result) {
    die("Query gagal: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8" />
    <link rel="icon" href="asset/icon.png" />
    <link rel="stylesheet" href="admin.css" />
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Categories</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo-details">
            <i class="bx bx-category"></i>
            <span class="logo_name">Logo</span>
        </div>
        <ul class="nav-links">
            <li>
                <a href="admin.php" class="active">
                    <i class="bx bx-grid-alt"></i>
                    <span class="links_name">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="categories.php">
                    <i class="bx bx-box"></i>
                    <span class="links_name">Categories</span>
                </a>
            </li>
            <li>
                <a href="login.php">
                    <i class="bx bx-log-out"></i>
                    <span class="links_name">Log out</span>
                </a>
            </li>
        </ul>
    </div>
    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <i class="bx bx-menu sidebarBtn"></i>
            </div>
        </nav>
        <div class="home-content">
            <!-- Form Filter -->
            <form method="GET" action="categories.php">
                <div class="selection-container">
                    <div class="dropdown">
                        <h3>Transportation</h3>
                        <select name="transportation" id="transportation">
                            <option value="">Select Transportation</option>
                            <?php while ($row = mysqli_fetch_assoc($transportationResult)) : ?>
                                <option value="<?= $row['transportation'] ?>" <?= ($filterTransportation == $row['transportation']) ? 'selected' : '' ?>>
                                    <?= $row['transportation'] ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-filter">Search</button>
            </form>

            <h3>Data Entries</h3>
            <button type="button" class="btn btn-tambah">
                <a href="entry-categories.php">Add Data</a>
            </button>
            <!-- Table Data -->
            <table class="table-data" id="dataTable">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Transportation</th>
                        <th scope="col">Kelas</th>
                        <th scope="col">Fasilitas</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Menampilkan data dari database
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['id'] . "</td>";
                            echo "<td>" . $row['transportation'] . "</td>";
                            echo "<td>" . $row['kelas'] . "</td>";
                            echo "<td>" . $row['fasilitas'] . "</td>";
                            echo "<td>" . $row['harga'] . "</td>";
                            echo "<td>
                                    <a href='categories-edit.php?edit_id=" . $row['id'] . "' class='btn-edit'>Edit</a>
                                    <a href='categories-delete.php?id=" . $row['id'] . "' class='btn-delete' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                  </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No data found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <br>
            <button type="button" class="btn btn-cetak">
                <a href="categories-cetak.php">Print</a>
            </button>
        </div>
    </section>

    <script>
        let sidebar = document.querySelector(".sidebar");
        let sidebarBtn = document.querySelector(".sidebarBtn");
        sidebarBtn.onclick = function () {
            sidebar.classList.toggle("active");
            if (sidebar.classList.contains("active")) {
                sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
            } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
        };
    </script>
</body>
</html>

<?php
// Close database connection
mysqli_close($conn);
?>