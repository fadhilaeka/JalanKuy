<?php
// Include koneksi ke database
include('koneksi.php');

// Initialize the results variable
$bookings = [];

if (isset($_GET['order_id']) && !empty($_GET['order_id'])) {
    // Get the name input from the user
    $order_id = $_GET['order_id'];
    
    // Query the database to find the bookings by name
    $query = "SELECT * FROM tb_booking WHERE nama LIKE '%$order_id%'";
    $result = mysqli_query($conn, $query);

    // Check for query error
    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    // Fetch all the results
    while ($row = mysqli_fetch_assoc($result)) {
        $bookings[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Cek Pesanan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <div class="logo"><img src="logo.png" alt="my-logo"></div>
        <div class="menu">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="booking.php">Booking</a></li>
                <li><a href="cek-pesanan.php">Cek Pesanan</a></li>
            </ul>     
        </div>
    </nav>

    <section id="cek_pesanan">
        <div class="tengah">
            <h1>Cek Pesanan Anda</h1>
            <form method="GET" action="cek-pesanan.php">
                <label for="order_id">Masukkan Nama Pemesan Anda:</label><br>
                <input type="text" id="order_id" name="order_id" placeholder="Contoh: John Doe" required><br><br>
                <button type="submit">Cek Pesanan</button>
            </form>
            
            <!-- Display bookings table if there are results -->
            <?php if (!empty($bookings)) : ?>
                <div id="hasil">
                    <h2>Detail Pesanan</h2>
                    <table id="pesananTable" border="1">
                        <thead>
                            <tr>
                                <th>Nama Pemesan</th>
                                <th>Tanggal</th>
                                <th>Transportasi</th>
                                <th>Asal</th>
                                <th>Tujuan</th>
                                <th>Waktu Keberangkatan</th>
                                <th>Kelas</th>
                                <th>Harga</th>
                                <th>Tindakan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking) : ?>
                                <tr>
                                    <td><?= $booking['nama'] ?></td>
                                    <td><?= $booking['tanggal'] ?></td>
                                    <td><?= $booking['transportation'] ?></td>
                                    <td><?= $booking['asal'] ?></td>
                                    <td><?= $booking['tujuan'] ?></td>
                                    <td><?= $booking['waktu'] ?></td>
                                    <td><?= $booking['kelas'] ?></td>
                                    <td><?= $booking['harga'] ?></td>
                                    <td><a href="cancel-booking.php?id=<?= $booking['id'] ?>" class="btn-delete">Cancel</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php elseif (isset($_GET['order_id'])) : ?>
                <p>Pesanan dengan nama tersebut tidak ditemukan.</p>
            <?php endif; ?>
        </div>
    </section>

</body>
</html>

<?php
// Close database connection
mysqli_close($conn);
?>