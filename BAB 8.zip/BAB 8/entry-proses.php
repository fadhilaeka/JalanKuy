<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_layanan_transportasi"; // replace with your actual database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$transportation = $_POST['transportation'];
$kelas = $_POST['kelas'];
$fasilitas = $_POST['fasilitas'];
$harga = $_POST['harga'];

// Insert data into the database
$sql = "INSERT INTO tb_categories (transportation, kelas, fasilitas, harga) VALUES ('$transportation', '$kelas', '$fasilitas', '$harga')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
    // Redirect to categories page after successful insertion
    header('Location: categories.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>