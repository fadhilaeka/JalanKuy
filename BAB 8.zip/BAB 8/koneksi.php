<?php
$servername = "localhost";
$username = "root"; // username bawaan XAMPP/Laragon
$password = ""; // kosongkan jika tidak ada password
$database = "db_layanan_transportasi"; // ganti sesuai database kamu

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
} else {
    echo "Koneksi berhasil!";
}
?>
