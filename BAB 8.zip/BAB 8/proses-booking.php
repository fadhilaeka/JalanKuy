<?php
// Include koneksi ke database
include('koneksi.php');

// Pastikan data yang diperlukan ada
if (isset($_POST['nama']) && isset($_POST['tanggal']) && isset($_POST['transportation']) && isset($_POST['asal']) && isset($_POST['tujuan']) && isset($_POST['waktu']) && isset($_POST['kelas']) && isset($_POST['harga'])) {
    // Ambil data dari form
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']);
    $transportation = mysqli_real_escape_string($conn, $_POST['transportation']);
    $asal = mysqli_real_escape_string($conn, $_POST['asal']);
    $tujuan = mysqli_real_escape_string($conn, $_POST['tujuan']);
    $waktu = mysqli_real_escape_string($conn, $_POST['waktu']);
    $kelas = mysqli_real_escape_string($conn, $_POST['kelas']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);

    // Query untuk memasukkan data ke tabel
    $query = "INSERT INTO tb_booking (nama, tanggal, transportation, asal, tujuan, waktu, kelas, harga) VALUES ('$nama', '$tanggal', '$transportation', '$asal', '$tujuan', '$waktu', '$kelas', '$harga')";

    if (mysqli_query($conn, $query)) {
        echo "Pesanan berhasil ditambahkan!";
        header('Location: cek-pesanan.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo "Data tidak lengkap.";
}

// Tutup koneksi database
mysqli_close($conn);
?>